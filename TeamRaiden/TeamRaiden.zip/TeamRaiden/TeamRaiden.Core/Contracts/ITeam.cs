﻿namespace TeamRaiden.Core.Contracts.Team
{
    using System.Collections.Generic;

    using Infrastructure.Classes;
    using Infrastructure.Enumerations;
    using Infrastructure.Structs;

    public interface ITeam
    {
        string TeamName { get; }
        ICollection<Player> Players { get; }
        Coach Coach { get; }
        uint Points { get; }
        int TotalTeamCapability { get; }

        void AddPoints(uint points);
        void SwitchPlayers(Player a, Player b);
        void ClearPoints();
   }
}
