﻿namespace TeamRaiden.Core.Contracts.Group
{
    using System;
    using System.Collections.Generic;

    using Team;
<<<<<<< HEAD
    using Infrastructure.Enumerations;
    using Infrastructure.Structs;

    public interface IGroup
    {
        ICollection<Team> Teams { get; }
        GroupName GroupName { get; }
        void AddTeam(Team team);
        void RemoveTeam(Team team);
    }
=======
   public interface IGroup
   {
      IList<ITeam> Teams { get; }
      GroupName GroupName { get; }
   }
>>>>>>> origin/master
}
