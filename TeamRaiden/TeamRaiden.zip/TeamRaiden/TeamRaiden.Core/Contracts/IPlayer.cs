﻿namespace TeamRaiden.Core.Contracts
{
    using TeamRaiden.Core.Infrastructure.Enumerations;

    interface IPlayer : IHuman
    {
        int Capability { get; }
        int PlayerNumber { get; }
        PlayerPositionType PlayerPosition { get; }
        PlayerType PlayerType { get; }
    }
}
