﻿namespace TeamRaiden.Core.Contracts
{
   interface ICoach: IHuman
   {
        int CoachCapability { get; }
   }
}
