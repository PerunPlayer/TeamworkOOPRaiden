﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamRaiden.Core.Infrastructure.Classes;
using TeamRaiden.Core.Infrastructure.Enumerations;
using TeamRaiden.Core.Infrastructure.Structs;

namespace _01.TeamRaiden.WFClient.TeamsInfo
{
    public class TeamsInfo
    {
        public void Info()
        {

        }
    }
}
                             