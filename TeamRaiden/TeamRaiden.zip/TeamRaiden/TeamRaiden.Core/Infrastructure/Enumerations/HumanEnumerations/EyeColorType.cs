﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamRaiden.Core.Infrastructure.Enumerations.HumanEnumerations
{
    public enum EyeColorType
    {
        NotSet = 0,
        Blue = 1,
        Brown = 2,
        Mixed = 3,
        Green = 4,
        Black = 5
    }
}
