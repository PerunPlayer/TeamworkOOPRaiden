﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamRaiden.Core.Infrastructure.Enumerations.HumanEnumerations
{
    public enum RaceType
    {
        NotSet = 0,
        Caucasian=1,
        Mongolian=2,
        Negroid=3
    }
}
