﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamRaiden.Core.Infrastructure.Enumerations.HumanEnumerations
{
    public enum ReligionType
    {
        NotSet = 0,
        Christianity = 1,
        Islam = 2,
        Hinduism = 3,
        ChineseFolkReligion = 4,
        Buddhism = 5,
        Ateizm=6

    }
}
