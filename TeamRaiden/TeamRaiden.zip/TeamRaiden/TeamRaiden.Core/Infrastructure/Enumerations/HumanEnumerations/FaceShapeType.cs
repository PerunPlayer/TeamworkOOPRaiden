﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamRaiden.Core.Infrastructure.Enumerations.HumanEnumerations
{
  public  enum FaceShapeType
    {
        NotSet = 0,
        Oval = 1,
        Round = 2,
        Diamond = 3,
        Long = 4,
        Square = 5,
        Heart = 6

    }
}
