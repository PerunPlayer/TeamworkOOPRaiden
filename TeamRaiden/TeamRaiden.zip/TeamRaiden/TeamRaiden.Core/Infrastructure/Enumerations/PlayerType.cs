﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamRaiden.Core.Infrastructure.Enumerations
{
    public enum PlayerType
    {
        NotSet = 0,
        Starter = 1,
        Substitute = 2
    }
}
