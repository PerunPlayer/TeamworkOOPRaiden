﻿namespace TeamRaiden.ConsoleClient
{
    using Core.Infrastructure.Classes;
    using Core.Infrastructure.Enumerations;
    using Core.Infrastructure.Structs;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class StartUp
    {


        static void Main()
        {

        }
    }
}
