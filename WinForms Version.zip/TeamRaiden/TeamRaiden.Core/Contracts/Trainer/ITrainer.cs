﻿namespace TeamRaiden.Core.Contracts.Trainer
{
   using Human;
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Text;
   using System.Threading.Tasks;

   interface ITrainer: IHuman
   {
   }
}
